import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:qr_flutter/qr_flutter.dart';

void main() {
  runApp(const AttendanceApp());
}

class AttendanceApp extends StatelessWidget {
  const AttendanceApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'QR School Attendance',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo),
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

class AttendanceRecord {
  AttendanceRecord({required this.name, required this.className, required this.time});
  final String name;
  final String className;
  final DateTime time;
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final _nameController = TextEditingController();
  final _classController = TextEditingController(text: '8-A');
  final List<AttendanceRecord> _records = [];

  @override
  void dispose() {
    _nameController.dispose();
    _classController.dispose();
    super.dispose();
  }

  String get _studentQrData {
    final name = _nameController.text.trim();
    final className = _classController.text.trim();
    if (name.isEmpty || className.isEmpty) return '';
    return 'SCHOOL_ATTENDANCE|${Uri.encodeComponent(name)}|${Uri.encodeComponent(className)}';
  }

  void _markAttendance(String raw) {
    final parts = raw.split('|');
    if (parts.length != 3 || parts[0] != 'SCHOOL_ATTENDANCE') {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('यह QR इस ऐप का छात्र QR नहीं है।')),
      );
      return;
    }
    final name = Uri.decodeComponent(parts[1]);
    final className = Uri.decodeComponent(parts[2]);
    final alreadyMarked = _records.any((r) =>
        r.name.toLowerCase() == name.toLowerCase() &&
        r.className.toLowerCase() == className.toLowerCase() &&
        r.time.day == DateTime.now().day &&
        r.time.month == DateTime.now().month &&
        r.time.year == DateTime.now().year);
    if (alreadyMarked) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('$name की आज की हाज़िरी पहले से लगी है।')),
      );
      return;
    }
    setState(() => _records.insert(
          0,
          AttendanceRecord(name: name, className: className, time: DateTime.now()),
        ));
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('$name की हाज़िरी लग गई।')),
    );
  }

  Future<void> _openScanner() async {
    await Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => ScannerPage(onScanned: _markAttendance),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final qrData = _studentQrData;
    return Scaffold(
      appBar: AppBar(
        title: const Text('QR School Attendance'),
        centerTitle: true,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('1. छात्र का QR बनाएं',
                      style: Theme.of(context).textTheme.titleLarge),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _nameController,
                    decoration: const InputDecoration(
                      labelText: 'छात्र का नाम',
                      border: OutlineInputBorder(),
                    ),
                    onChanged: (_) => setState(() {}),
                  ),
                  const SizedBox(height: 10),
                  TextField(
                    controller: _classController,
                    decoration: const InputDecoration(
                      labelText: 'कक्षा / डिवीज़न',
                      border: OutlineInputBorder(),
                    ),
                    onChanged: (_) => setState(() {}),
                  ),
                  const SizedBox(height: 12),
                  if (qrData.isNotEmpty) ...[
                    Center(
                      child: QrImageView(
                        data: qrData,
                        size: 210,
                        backgroundColor: Colors.white,
                      ),
                    ),
                    const Center(child: Text('QR को स्कैन करके हाज़िरी लगाएं')),
                  ] else
                    const Text('QR देखने के लिए नाम और कक्षा भरें।'),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          FilledButton.icon(
            onPressed: _openScanner,
            icon: const Icon(Icons.qr_code_scanner),
            label: const Text('QR स्कैन करके हाज़िरी लगाएं'),
          ),
          const SizedBox(height: 20),
          Text('2. आज की हाज़िरी (${_records.length})',
              style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 8),
          if (_records.isEmpty)
            const Card(
              child: Padding(
                padding: EdgeInsets.all(18),
                child: Text('अभी कोई हाज़िरी दर्ज नहीं हुई है।'),
              ),
            )
          else
            ..._records.map(
              (r) => Card(
                child: ListTile(
                  leading: const CircleAvatar(child: Icon(Icons.check)),
                  title: Text(r.name),
                  subtitle: Text(
                    '${r.className} • ${r.time.hour.toString().padLeft(2, '0')}:${r.time.minute.toString().padLeft(2, '0')}',
                  ),
                  trailing: const Text('Present'),
                ),
              ),
            ),
          const SizedBox(height: 12),
          const Text(
            'ध्यान दें: यह शुरुआती संस्करण हाज़िरी को केवल ऐप खुला रहने तक मेमोरी में रखता है। स्थायी सेविंग और स्कूल/टीचर लॉगिन बाद में जोड़े जा सकते हैं।',
            style: TextStyle(color: Colors.black54),
          ),
        ],
      ),
    );
  }
}

class ScannerPage extends StatefulWidget {
  const ScannerPage({super.key, required this.onScanned});
  final ValueChanged<String> onScanned;

  @override
  State<ScannerPage> createState() => _ScannerPageState();
}

class _ScannerPageState extends State<ScannerPage> {
  bool _handled = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('QR स्कैन करें')),
      body: MobileScanner(
        onDetect: (capture) {
          if (_handled) return;
          final barcode = capture.barcodes.firstOrNull;
          final value = barcode?.rawValue;
          if (value == null || value.isEmpty) return;
          _handled = true;
          widget.onScanned(value);
          Navigator.of(context).pop();
        },
      ),
    );
  }
}
